Contributing
============

If you want to contribute, please use [the suckless coding style](http://suckless.org/coding_style).

Feel free to add yourself to [CONTRIBUTORS.md](CONTRIBUTORS.md) afterwards if you want.
